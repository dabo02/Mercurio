angular.module('users')
.controller('EditProfileController', function($scope) {

    $scope.ringtones = [
        'active', 'alert', 'aqua', 'ascending', 'bar', 'bubbles', 'chimes', 'elegant', 'galaxy', 'google', 'ladder',
        'medieval', 'morning', 'notification', 'plus', 'random', 'retro', 'soft', 'super', 'whistle'
    ];


});